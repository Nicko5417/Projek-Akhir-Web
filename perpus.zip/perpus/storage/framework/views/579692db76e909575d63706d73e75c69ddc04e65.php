<!-- Container utama tanpa container Bootstrap -->
<div class="row">
    <!-- SIDEBAR (di sebelah kiri) -->
    <div class="col-md-3 sidebar">
        <img src="<?php echo e(asset('gambar')); ?>/sidebar.jpg" class="img-fluid" alt="Sidebar Image">
    </div>
    
    <!-- Konten utama (di sebelah kanan) -->
    <div class="col-md-9 main-content">
        <!-- Konten utama bisa diisi di sini -->
        <p>Konten utama di sini</p>
    </div>
</div>
<?php /**PATH C:\uas\perpus\resources\views/sidebar.blade.php ENDPATH**/ ?>