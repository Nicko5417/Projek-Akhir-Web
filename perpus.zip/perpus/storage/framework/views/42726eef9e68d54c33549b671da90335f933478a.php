<?php $__env->startPush('styles'); ?>
<style>
    /* CSS khusus untuk konten */
</style>
<?php $__env->stopPush(); ?>

<!-- Konten -->
<?php echo $__env->yieldContent('isihalaman'); ?>
<?php /**PATH C:\uas\perpus\resources\views/konten.blade.php ENDPATH**/ ?>