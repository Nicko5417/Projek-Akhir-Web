@push('styles')
<style>
    /* CSS khusus untuk konten */
</style>
@endpush

<!-- Konten -->
@yield('isihalaman')
